package com.bedrockproxy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * UDP Proxy Service — cœur de l'application.
 *
 * Fonctionnement :
 * 1. Lance un thread qui écoute les paquets UDP LAN de Minecraft (port 19132 local)
 * 2. Broadcast les réponses "Unconnected Pong" sur le réseau local pour que la
 *    console voit le serveur dans l'onglet Amis / LAN
 * 3. Forward tous les paquets UDP entre la console et le vrai serveur distant
 */
public class ProxyService extends Service {

    private static final String TAG = "BedrockProxy";
    private static final String CHANNEL_ID = "proxy_channel";
    private static final int NOTIF_ID = 1;

    public static final String ACTION_START = "com.bedrockproxy.START";
    public static final String ACTION_STOP  = "com.bedrockproxy.STOP";
    public static final String EXTRA_IP     = "server_ip";
    public static final String EXTRA_PORT   = "server_port";

    // RakNet packet IDs
    private static final byte ID_UNCONNECTED_PING         = 0x01;
    private static final byte ID_UNCONNECTED_PING_OPEN    = 0x02;
    private static final byte ID_UNCONNECTED_PONG         = 0x1C;
    private static final byte[] OFFLINE_MESSAGE_DATA_ID   = {
        0x00,(byte)0xFF,(byte)0xFF,0x00,(byte)0xFE,(byte)0xFE,(byte)0xFE,(byte)0xFE,
        (byte)0xFD,(byte)0xFD,(byte)0xFD,(byte)0xFD,0x12,0x34,0x56,0x78
    };

    private static final int LAN_BROADCAST_PORT = 19132;
    private static final int BUFFER_SIZE = 2048;

    private static volatile boolean running = false;
    private ExecutorService executor;
    private final AtomicBoolean stopFlag = new AtomicBoolean(false);

    private String remoteIp;
    private int remotePort;

    // Sockets
    private DatagramSocket proxySocket;   // listens locally, forwards to remote
    private DatagramSocket lanSocket;     // broadcasts fake LAN pong

    public static boolean isRunning() { return running; }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        executor = Executors.newCachedThreadPool();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        if (ACTION_STOP.equals(intent.getAction())) {
            stopProxy();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_START.equals(intent.getAction())) {
            remoteIp   = intent.getStringExtra(EXTRA_IP);
            remotePort = intent.getIntExtra(EXTRA_PORT, 19132);
            startForeground(NOTIF_ID, buildNotification("Proxy actif → " + remoteIp + ":" + remotePort));
            stopFlag.set(false);
            running = true;
            executor.submit(this::runProxy);
            executor.submit(this::runLanBroadcaster);
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopProxy();
        executor.shutdownNow();
        super.onDestroy();
    }

    // ─── PROXY CORE ────────────────────────────────────────────────────────────

    private void runProxy() {
        log("🔌 Résolution de " + remoteIp + "...");
        InetAddress remoteAddr;
        try {
            remoteAddr = InetAddress.getByName(remoteIp);
            log("✅ Résolu : " + remoteAddr.getHostAddress());
        } catch (Exception e) {
            log("❌ Impossible de résoudre l'IP : " + e.getMessage());
            stopSelf();
            return;
        }

        try {
            proxySocket = new DatagramSocket(LAN_BROADCAST_PORT);
            proxySocket.setBroadcast(true);
            proxySocket.setSoTimeout(1000);
            log("📡 En écoute sur le port " + LAN_BROADCAST_PORT + " (UDP)");
            log("💡 Ouvre Minecraft → Amis → LAN");
        } catch (Exception e) {
            log("❌ Impossible d'ouvrir le socket local : " + e.getMessage());
            log("   (Le port est peut-être déjà utilisé)");
            stopSelf();
            return;
        }

        byte[] buf = new byte[BUFFER_SIZE];

        // We keep track of the last console address to relay responses back
        InetAddress consoleAddr = null;
        int consolePort = -1;

        while (!stopFlag.get()) {
            try {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                try {
                    proxySocket.receive(packet);
                } catch (java.net.SocketTimeoutException e) {
                    continue; // just loop to check stopFlag
                }

                byte[] data = Arrays.copyOf(packet.getData(), packet.getLength());
                byte packetId = data[0];

                // Intercept Unconnected Ping — send fake Pong locally
                if (packetId == ID_UNCONNECTED_PING || packetId == ID_UNCONNECTED_PING_OPEN) {
                    consoleAddr = packet.getAddress();
                    consolePort = packet.getPort();

                    // Forward ping to real server too
                    DatagramPacket forward = new DatagramPacket(data, data.length, remoteAddr, remotePort);
                    proxySocket.send(forward);

                    log("🏓 Ping reçu de " + consoleAddr.getHostAddress() + " → forwardé");
                    continue;
                }

                // From console → forward to remote
                if (packet.getAddress() != null &&
                    !packet.getAddress().equals(remoteAddr)) {
                    consoleAddr = packet.getAddress();
                    consolePort = packet.getPort();
                    DatagramPacket forward = new DatagramPacket(data, data.length, remoteAddr, remotePort);
                    proxySocket.send(forward);
                }
                // From remote → forward back to console
                else if (consoleAddr != null) {
                    DatagramPacket reply = new DatagramPacket(data, data.length, consoleAddr, consolePort);
                    proxySocket.send(reply);
                }

            } catch (Exception e) {
                if (!stopFlag.get()) {
                    log("⚠ Erreur proxy : " + e.getMessage());
                }
            }
        }

        try { if (proxySocket != null) proxySocket.close(); } catch (Exception ignored) {}
        log("⏹ Proxy arrêté.");
    }

    // ─── LAN BROADCASTER ───────────────────────────────────────────────────────
    /**
     * Every 1.5s, sends a fake "Unconnected Pong" broadcast on port 19132
     * so the console's Friends tab sees "BedrockProxy" as a LAN game.
     */
    private void runLanBroadcaster() {
        try {
            lanSocket = new DatagramSocket();
            lanSocket.setBroadcast(true);

            InetAddress broadcast = InetAddress.getByName("255.255.255.255");
            long serverGuid = System.currentTimeMillis();
            String motd = "MCPE;BedrockProxy;800;1.21.0;0;20;12345678;" + remoteIp + ":" + remotePort + ";Survival;1;19132;19133;";

            while (!stopFlag.get()) {
                byte[] pongData = buildUnconnectedPong(serverGuid, motd);
                DatagramPacket pong = new DatagramPacket(pongData, pongData.length, broadcast, LAN_BROADCAST_PORT);
                try {
                    lanSocket.send(pong);
                } catch (Exception e) {
                    if (!stopFlag.get()) log("⚠ Broadcaster : " + e.getMessage());
                }
                Thread.sleep(1500);
            }
        } catch (Exception e) {
            if (!stopFlag.get()) log("⚠ LAN broadcaster : " + e.getMessage());
        } finally {
            try { if (lanSocket != null) lanSocket.close(); } catch (Exception ignored) {}
        }
    }

    private byte[] buildUnconnectedPong(long serverGuid, String motd) {
        byte[] motdBytes = motd.getBytes();
        // 1 (id) + 8 (ping time) + 8 (guid) + 16 (magic) + 2 (motd len) + motd
        int size = 1 + 8 + 8 + 16 + 2 + motdBytes.length;
        ByteBuffer buf = ByteBuffer.allocate(size).order(ByteOrder.BIG_ENDIAN);

        buf.put(ID_UNCONNECTED_PONG);           // packet id
        buf.putLong(System.currentTimeMillis()); // ping time
        buf.putLong(serverGuid);                 // server GUID
        buf.put(OFFLINE_MESSAGE_DATA_ID);        // RakNet magic
        buf.putShort((short) motdBytes.length);  // MOTD length
        buf.put(motdBytes);                      // MOTD

        return buf.array();
    }

    // ─── HELPERS ───────────────────────────────────────────────────────────────

    private void stopProxy() {
        stopFlag.set(true);
        running = false;
        try { if (proxySocket != null) proxySocket.close(); } catch (Exception ignored) {}
        try { if (lanSocket != null)   lanSocket.close();   } catch (Exception ignored) {}
    }

    private void log(String msg) {
        Log.d(TAG, msg);
        Intent intent = new Intent(MainActivity.ACTION_LOG);
        intent.putExtra(MainActivity.EXTRA_LOG_MSG, msg);
        sendBroadcast(intent);
    }

    private Notification buildNotification(String text) {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BedrockProxy")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "Proxy Status", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Statut du proxy Minecraft Bedrock");
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }
}
