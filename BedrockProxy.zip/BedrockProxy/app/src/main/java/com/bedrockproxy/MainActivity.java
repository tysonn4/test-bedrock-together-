package com.bedrockproxy;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

public class MainActivity extends AppCompatActivity {

    private EditText etServerIp;
    private EditText etServerPort;
    private Button btnToggle;
    private TextView tvStatus;
    private TextView tvLocalIp;
    private TextView tvLog;
    private boolean isRunning = false;

    private SharedPreferences prefs;
    private static final String PREF_IP = "last_ip";
    private static final String PREF_PORT = "last_port";

    public static final String ACTION_LOG = "com.bedrockproxy.LOG";
    public static final String EXTRA_LOG_MSG = "msg";

    private final BroadcastReceiver logReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra(EXTRA_LOG_MSG);
            if (msg != null) appendLog(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("bedrock_proxy", MODE_PRIVATE);

        etServerIp   = findViewById(R.id.etServerIp);
        etServerPort = findViewById(R.id.etServerPort);
        btnToggle    = findViewById(R.id.btnToggle);
        tvStatus     = findViewById(R.id.tvStatus);
        tvLocalIp    = findViewById(R.id.tvLocalIp);
        tvLog        = findViewById(R.id.tvLog);

        // Restore last values
        etServerIp.setText(prefs.getString(PREF_IP, ""));
        etServerPort.setText(prefs.getString(PREF_PORT, "19132"));

        // Show local IP
        tvLocalIp.setText("📱 IP locale : " + getLocalIp());

        btnToggle.setOnClickListener(v -> {
            if (!isRunning) startProxy();
            else stopProxy();
        });

        // Save as user types
        etServerIp.addTextChangedListener(new SimpleTextWatcher() {
            public void afterTextChanged(Editable s) {
                prefs.edit().putString(PREF_IP, s.toString()).apply();
            }
        });
        etServerPort.addTextChangedListener(new SimpleTextWatcher() {
            public void afterTextChanged(Editable s) {
                prefs.edit().putString(PREF_PORT, s.toString()).apply();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(ACTION_LOG);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(logReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(logReceiver, filter);
        }
        // Sync state with service
        isRunning = ProxyService.isRunning();
        updateUI();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { unregisterReceiver(logReceiver); } catch (Exception ignored) {}
    }

    private void startProxy() {
        String ip = etServerIp.getText().toString().trim();
        String portStr = etServerPort.getText().toString().trim();

        if (ip.isEmpty()) {
            etServerIp.setError("Entre une IP ou un domaine");
            return;
        }

        int port;
        try {
            port = Integer.parseInt(portStr);
            if (port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            etServerPort.setError("Port invalide (1-65535)");
            return;
        }

        tvLog.setText("");
        appendLog("▶ Démarrage du proxy...");
        appendLog("→ Serveur cible : " + ip + ":" + port);

        Intent intent = new Intent(this, ProxyService.class);
        intent.setAction(ProxyService.ACTION_START);
        intent.putExtra(ProxyService.EXTRA_IP, ip);
        intent.putExtra(ProxyService.EXTRA_PORT, port);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }

        isRunning = true;
        updateUI();
    }

    private void stopProxy() {
        Intent intent = new Intent(this, ProxyService.class);
        intent.setAction(ProxyService.ACTION_STOP);
        startService(intent);
        isRunning = false;
        updateUI();
        appendLog("⏹ Proxy arrêté.");
    }

    private void updateUI() {
        if (isRunning) {
            btnToggle.setText("⏹  ARRÊTER");
            btnToggle.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.red));
            tvStatus.setText("✅ Proxy actif");
            tvStatus.setTextColor(getColor(R.color.green));
            etServerIp.setEnabled(false);
            etServerPort.setEnabled(false);
        } else {
            btnToggle.setText("▶  LANCER");
            btnToggle.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.accent));
            tvStatus.setText("⏸ Inactif");
            tvStatus.setTextColor(getColor(R.color.muted));
            etServerIp.setEnabled(true);
            etServerPort.setEnabled(true);
        }
    }

    private void appendLog(String msg) {
        runOnUiThread(() -> {
            String current = tvLog.getText().toString();
            tvLog.setText(current.isEmpty() ? msg : current + "\n" + msg);
        });
    }

    private String getLocalIp() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                if (iface.isLoopback() || !iface.isUp()) continue;
                Enumeration<InetAddress> addrs = iface.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    if (!addr.isLoopbackAddress() && addr.getHostAddress().contains(".")) {
                        return addr.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {}
        return "Inconnue";
    }

    abstract static class SimpleTextWatcher implements TextWatcher {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
    }
}
