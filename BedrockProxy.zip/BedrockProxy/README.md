# BedrockProxy 🎮

Clone de BedrockTogether — proxy UDP pour connecter une console Minecraft Bedrock
(Xbox, PlayStation) à n'importe quel serveur distant via l'onglet LAN / Amis.

## Comment ça marche

1. Le téléphone tourne un proxy UDP sur le port 19132
2. Il broadcast des faux paquets "Unconnected Pong" RakNet sur le réseau local
3. La console voit "BedrockProxy" dans l'onglet Amis → LAN
4. Tous les paquets UDP sont forwardés entre la console et le vrai serveur

## Compiler l'APK

### Option 1 — Android Studio (recommandé)
1. Installe [Android Studio](https://developer.android.com/studio)
2. Ouvre ce dossier comme projet
3. Attends la sync Gradle
4. Menu **Build → Build APK(s)**
5. L'APK est dans `app/build/outputs/apk/debug/`

### Option 2 — Ligne de commande
```bash
# macOS/Linux
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```
L'APK sera dans `app/build/outputs/apk/debug/app-debug.apk`

## Utilisation

1. Lance l'appli sur le téléphone
2. Entre l'IP/domaine et le port du serveur Bedrock (défaut: 19132)
3. Appuie sur **LANCER**
4. Sur la console, ouvre Minecraft → Jouer → Amis → LAN
5. Rejoins **"BedrockProxy"**
6. Une fois connecté, tu peux fermer l'appli

## Prérequis
- Téléphone et console sur le **même Wi-Fi**
- Android 8.0+ (API 26)
- Le serveur doit être un serveur **Bedrock Edition** (ou Java avec GeyserMC)
